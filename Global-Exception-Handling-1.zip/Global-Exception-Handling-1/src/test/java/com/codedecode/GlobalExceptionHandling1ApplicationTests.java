package com.codedecode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlobalExceptionHandling1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
